﻿namespace ECommerceApis.Helper
{
    public class ResponseMessage
    {
        public string status { get; set; }
        public string message { get; set; }
    }
}
